<?php
echo password_hash("1234", PASSWORD_BCRYPT);