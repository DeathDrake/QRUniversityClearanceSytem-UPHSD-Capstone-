export default {
    build: {
      outDir: 'public/react', // Output the build to the "public" folder
    },
  };
  